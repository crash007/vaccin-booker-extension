# vaccin-booker-extension

Kolla lediga covidvaccinationstider på några platser i Västernorrland

När en ledig tid dyker upp öppnas en ny flik som tar en direkt till bokningssidan.

## Installlera
Ladda ner `vac.zip` 

gå till addons/extensons

välj debugga tillägg

peka ut vac.zip

Nu är det bara att vänta på att en ledig tid ska dyka upp
