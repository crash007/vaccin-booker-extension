# vaccin-booker-extension

Kolla lediga covidvaccinationstider på några platser i Västernorrland

